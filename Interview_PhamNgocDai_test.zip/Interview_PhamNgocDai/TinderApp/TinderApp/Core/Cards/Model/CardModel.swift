//
//  CardModel.swift
//  TinderApp
//
//  Created by Ngoc Dai on 10/5/24.
//

import Foundation

struct CardModel {
    let user: User
}

extension CardModel: Identifiable, Hashable {
    var id: String { return user.id }
}
