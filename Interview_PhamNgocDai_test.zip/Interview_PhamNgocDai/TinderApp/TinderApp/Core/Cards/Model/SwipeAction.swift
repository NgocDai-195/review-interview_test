//
//  SwipeAction.swift
//  TinderApp
//
//  Created by Ngoc Dai on 10/6/24.
//

import Foundation

enum SwipeAction {
    case reject
    case like
}
