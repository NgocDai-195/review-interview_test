//
//  CurrentUserProfileView.swift
//  TinderApp
//
//  Created by Ngoc Dai on 10/6/24.
//

import SwiftUI

struct CurrentUserProfileView: View {
    @State private var showEditProfile = false
    
    let user: User
    
    var body: some View {
        NavigationStack {
            List {
                // header view
                CurrentUserProfileHeaderView(user: user)
                    .onTapGesture { showEditProfile.toggle() }
                
                // account info
                Section("Account information") {
                    HStack {
                        Text("Name")
                        
                        Spacer()
                        
                        Text(user.fullname)
                    }
                    
                    HStack {
                        Text("Email")
                        
                        Spacer()
                        
                        Text("test@gmail.com")
                    }
                }
                
                // legal
                Section("Legal") {
                    Text("Terms of Service")
                }
                
                
                // logout/deleted
                Section {
                    Button {
                        print("DEBUG: Logout here...")
                    } label: {
                        Text("Logout")
                    }.foregroundStyle(.red)
                }
               
                
                Section {
                    Button {
                        print("DEBUG: Delete Account here...")
                    } label: {
                        Text("Delete Account")
                    }.foregroundStyle(.red)
                }
            }
        }
        .navigationTitle("Profile")
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(isPresented: $showEditProfile) {
            EditProfileView(user: user)
        }
    }
}

struct CurrentUserProfileView_Previews: PreviewProvider {
    static var previews: some View {
        CurrentUserProfileView(user: MockData.users[0])
    }
}
