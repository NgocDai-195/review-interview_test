//
//  TinderAppApp.swift
//  TinderApp
//
//  Created by Ngoc Dai on 10/5/24.
//

import SwiftUI

@main
struct TinderTutorialApp: App {
    @StateObject var matchManager = MatchManager()
    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(matchManager)
        }
    }
}
