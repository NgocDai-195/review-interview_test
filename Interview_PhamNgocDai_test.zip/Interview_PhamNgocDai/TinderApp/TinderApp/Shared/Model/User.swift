//
//  User.swift
//  TinderApp
//
//  Created by Ngoc Dai on 10/5/24.
//

import Foundation

struct User: Identifiable, Hashable {
    let id: String
    let fullname: String
    let age: Int
    var profileImageURLs: [String]
}
