import UIKit

func solution(value1: Int, weight1: Int, value2: Int, weight2: Int, maxW: Int) -> Int {
    var maxValue = 0
    
    if (weight1 > maxW && weight2 > maxW) {
        print("You're not strong to bring them")
        return maxValue
    }
    
    // Check if we can take both items
    if weight1 + weight2 <= maxW {
        maxValue = max(maxValue, value1 + value2)
        print("You're strong enough to take both of the items with you.")
        return maxValue
    }
    
    // Check if we can take the first item
    if weight1 <= maxW {
        maxValue = max(maxValue, value1)
        if (value1 > value2) {
            maxValue = max(maxValue, value1)
            print("You can only carry the first item.")
            return maxValue
        }
    }
    
    if  (weight2 <= maxW) && (weight1 + weight2 > maxW) {
        maxValue = max(maxValue, value2)
        print("You can't take both items, but you can take any of them.")
    }
    
    return maxValue
}

// TDD for this code

//print(solution(value1: 10, weight1: 5, value2: 6, weight2: 8, maxW: 8))  // Output: 10

//print(solution(value1: 10, weight1: 5, value2: 6, weight2: 4, maxW: 9))  // Output: 16

//print(solution(value1: 5, weight1: 3, value2: 7, weight2: 4, maxW: 6))   // Output: 7

//print(solution(value1: 10, weight1: 5, value2: 6, weight2: 4, maxW: 8)) // Output 10

//print (solution(value1: 5, weight1: 3, value2: 7, weight2: 4, maxW: 6)) // Output 7

//print(solution(value1: 5, weight1: 10, value2: 6, weight2: 12, maxW: 5)) // Output 0

//print(solution(value1: 10, weight1: 15, value2: 6, weight2: 4, maxW: 10)) // Output 6

print(solution(value1: 10, weight1: 15, value2: 6, weight2: 12, maxW: 10)) // Output 0
